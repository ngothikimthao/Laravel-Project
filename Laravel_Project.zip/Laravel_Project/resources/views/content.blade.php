<body>
              <content>
                <div class="section">
                <div class="container_slide">
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img src="img/user/1.jpg" class="img_slide" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="img/user/2.jpg" class="img_slide" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="img/user/3.jpg" class="img_slide" alt="...">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
              </div>
               <div class="section">
                <div class="container_content">
                  <div class="col four">
                    <h1 class="icon">[]</h1>
                    <h1 class="service">Wow</h1>
                    <p>Wow wow wow wow wow wow wow wow wow wow wow wow wow</p>
                  </div>
                  <div class="col four">
                    <h1 class="icon">[]</h1>
                    <h1 class="service">Wow</h1>
                    <p>Wow wow wow wow wow wow wow wow wow</p>
                  </div>
                  <div class="responsivegroup"></div>
                  <div class="col four">
                    <h1 class="icon">[]</h1>
                    <h1 class="service">Wow</h1>
                    <p>Wow wow wow wow wow wow wow wow wow wow wow</p>
                  </div>
                  <div class="col four">
                    <h1 class="icon">[]</h1>
                    <h1 class="service">Wow</h1>
                    <p>Wow wow wow wow wow wow wow</p>
                  </div>
                  <div class="group"></div>
                </div>
              </div>

              <div class="container">
               <div class="row">
               <div class=" col-md-9 col-sm-9">
                
                  <center><h1>Wow wow</h1></center>
                  <h2>Wow wow wow!</h2>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow</p>
                  </div>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow wow</p>
                  </div>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow wow</p>
                  </div>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow wow</p>
                  </div>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow wow</p>
                  </div>
                  <div class="col three bg nopad pointer">
                    <div class="imgholder"></div>
                    <h1 class="feature">Wow</h1>
                    <p>Wow wow wow</p>
                  </div>
                  
                  
                  
                  <div class="group"></div>
                </div>
              
               <div class="col-md-3 col-sm-3">
                <img style="height: 100%; width: 100%" src="" alt="">
               </div>
               </div>
              </div>
              </content>
          
          
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>


       

