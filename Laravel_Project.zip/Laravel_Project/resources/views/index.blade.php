<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link href="{{asset('//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{asset('css/style.css') }}" rel="stylesheet">
    <link href="{{asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{asset('css/animate.css') }}" rel="stylesheet">
    <link href="{{asset('css/classy-nav.css') }}" rel="stylesheet">
    <link href="{{asset('font-awesome.css') }}" rel="stylesheet">
    <link href="{{asset('css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{asset('css/nice-select.css') }}" rel="stylesheet">
    <link href="{{asset('css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{asset('css/themify.css') }}" rel="stylesheet">
    <link href="{{asset('css/app.css') }}" rel="stylesheet">
</head>

<body>

    <!--Header -->
    @include('header')
    
    <!--Footer -->
    @include('footer')

    <!-- All Javascript Script  -->
    @include('script')

</html>