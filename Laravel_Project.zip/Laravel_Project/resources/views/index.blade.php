

    <!--Header -->
    @include('header')
    
    <!--Content -->
    @include('content')
    <!--Footer -->
    @include('footer')

    <!-- All Javascript Script  -->
    @include('script')

