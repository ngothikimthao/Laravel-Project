<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title -->
    <title>Đổi đồ cũ &amp; Xin chào</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link href="{{asset('//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{asset('css/style.css') }}" rel="stylesheet">
    <link href="{{asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{asset('css/animate.css') }}" rel="stylesheet">
    <link href="{{asset('css/classy-nav.css') }}" rel="stylesheet">
    <link href="{{asset('font-awesome.css') }}" rel="stylesheet">
    <link href="{{asset('css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{asset('css/nice-select.css') }}" rel="stylesheet">
    <link href="{{asset('css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{asset('css/themify.css') }}" rel="stylesheet">
    <link href="{{asset('css/app.css') }}" rel="stylesheet">

</head>
<body>
    <!-- Preloader -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <section class="breadcrumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/40.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2>Đăng bài</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="mag-breadcrumb py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Đăng bài</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Video Submit Area Start ##### -->
    <div class="video-submit-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <!-- Video Submit Content -->
                    <div class="video-submit-content mb-50 p-30 bg-white box-shadow">
                        <!-- Section Title -->
                        <div class="section-heading">
                            <h5>Đăng bài của bạn</h5>
                        </div>

                        <div class="video-info mt-30">
                            <form action="#" method="post">
                                <div class="form-group">
                                    <label for="upload-file">Tệp của bạn</label>
                                    <input type="file" class="form-control-file" id="upload-file">
                                </div>
                                <div class="form-group">
                                    <label for="upload-file">Tên bài viết</label>
                                    <input type="text" class="form-control" name="video-name">
                                </div>
                                <div class="form-group">
                                    <label for="upload-file">Nội dung</label>
                                    <textarea name="video-description" class="form-control" cols="30" rows="10"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="upload-file">Thể loại</label>
                                    <select name="video-catagory" class="form-control">
                                        <option value="blogs">Học sinh</option>
                                        <option value="news">Gia dụng</option>
                                        <option value="lifestyle">Áo quần</option>
                                        <option value="treading">Thể thao</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="upload-file">Tình trạng</label>
                                    <select name="video-language" class="form-control">
                                        <option value="en">Mới</option>
                                        <option value="spa">Cũ</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn mag-btn mt-30"><i class="fa fa-cloud-upload"></i> Đăng bài</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>