<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Favicon -->
    <title>Tôi Bạn &amp; Đồ Cũ</title>
    <!-- Stylesheet -->
    <link href="<?php echo e(asset('//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style_q.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/classy-nav.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/icon.css')); ?>" rel="stylesheet">
</head>

<body>
<!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Navbar Area -->
        <div class="mag-main-menu" id="sticker">
            <div class="classy-nav-container breakpoint-off">
                <!-- Menu -->
                <nav class="classy-navbar justify-content-between" id="magNav">

                    <!-- Nav brand -->
                    <a href="<?php echo e(route('getTrangchu')); ?>" class="nav-brand"><img src="img/user/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Nav Content -->
                    <div class="nav-content d-flex align-items-center">
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>
                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li class="active"><a href="<?php echo e(route('getTrangchu')); ?>">Trang Chủ</a></li>
                                    <li><a href="#">Đổi Đồ</a>
                                        <ul class="dropdown">
                                            <li><a href="index.html">Học Sinh</a></li>
                                            <li><a href="archive.html">Gia Dụng</a></li>
                                            <li><a href="video-post.html">Nhà Bếp</a></li>
                                            <li><a href="single-post.html">Áo Quần</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Câu Lạc bộ</a>
                                        <div class="megamenu">
                                            <ul class="single-mega cn-col-4">
                                                <li><a href="index.html">Trang Chủ</a></li>
                                                <li><a href="archive.html">Đổi Đồ</a></li>
                                                <li><a href="video-post.html">Chúng Tôi</a></li>
                                                <li><a href="single-post.html">Đăng Xuất</a></li>
                                            </ul>
                                            
                                    </li>
                                    <li><a href="about.html">Chúng Tôi</a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <div class="top-meta-data d-flex align-items-center">
                            <!-- Top Search Area -->
                            <div class="top-search-area">
                                <form action="index.html" method="post">
                                    <input type="search" name="top-search" id="topSearch" placeholder="Gõ tìm kiếm...">
                                    <button type="submit" class="btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                                </form>
                            </div>
                            <!-- Login -->
                            <a href="<?php echo e(route('getLogin')); ?>" class="login-btn"><i class="fa fa-user" aria-hidden="true"></i></a>
                            <!-- Submit Video -->
                            <a href="<?php echo e(route('getPost')); ?>" class="submit-video"><span><i class="fa fa-cloud-upload"></i></span> <span class="video-text">Đăng Bài</span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header><?php /**PATH E:\IT\Laravel_Project\resources\views/header.blade.php ENDPATH**/ ?>